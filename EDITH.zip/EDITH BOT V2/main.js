const {
    WAConnection: _WAConnection,
    MessageType,
    Presence,
    Mimetype,
    GroupSettingChange
} = require('@adiwajshing/baileys')
const simple = require('./lib/simple.js')
const WAConnection = simple.WAConnection(_WAConnection)
const fs = require('fs')
const { banner, start, success } = require('./lib/functions')
const { color } = require('./lib/color')
const chalk = require('chalk')
const moment = require("moment-timezone")
const { spawn, exec, execSync } = require("child_process")
const cp = require('child_process')
 const figlet = require('figlet')
 
require('./index.js')
nocache('./index.js', module => console.log(color('├ [ INFO ]', 'cyan'), `${module} updated`))
nocache('./main.js', module => console.log(color('├ [ INFO ]', 'cyan'), `${module} updated`))

const starts = async (yoks = new WAConnection(), mek) => {
    yoks.logger.backel = 'warn'
    yoks.version = [2, 2140, 12]
    yoks.browserDescription = [ 'Peler', 'Safari', '7.0' ]
    yoks.setMaxListeners(0)
yoks.removeAllListeners('close')
yoks.removeAllListeners('error')
m = simple.smsg(yoks, mek)
console.log(color(figlet.textSync('BOT', {
		font: 'Alpha',
		horizontalLayout: 'center',
		vertivalLayout: 'center',
		width: 50,
		whitespaceBreak: false
	}), 'cyan'))
    yoks.on('qr', () => {
        console.log(color('[','white'), color('!','red'), color(']','white'), color(' Scan bang'))
    })
    yoks.on('message-delete', async (m) => {

    	if (!m.key.fromMe && m.key.fromMe) return

const jam = moment.tz('Asia/Jakarta').format('HH:mm:ss')

let d = new Date

let locale = 'id'

let gmt = new Date(0).getTime() - new Date('1 Januari 2021').getTime()

let weton = ['Pahing', 'Pon','Wage','Kliwon','Legi'][Math.floor(((d * 1) + gmt) / 84600000) % 5]

let week = d.toLocaleDateString(locale, { weekday: 'long' })

let calender = d.toLocaleDateString(locale, {

day: 'numeric',

month: 'long',

year: 'numeric'

})

const type = Object.keys(m.message)[0]

    yoks.sendMessage(yoks.user.jid, `╭────「  MESSAGE DELETED 」───\n├\n├ Nama : *@${m.participant.split("@")[0]}*\n├ Time : *${jam} ${week} ${calender}*\n├ Type : *${type}*\n├\n╰────「  MESSAGE DELETED」───`, MessageType.text, {quoted: m.message, contextInfo: {"mentionedJid": [m.participant]}})

      yoks.copyNForward(yoks.user.jid, m.message).catch(e => console.log(e, m))

    console.log(m.message)

    })
		yoks.on('close', async () => {
  if (yoks.state == 'close') {
  yoks.logger.error('Reconnecting...')
    await yoks.loadAuthInfo('./session.json')
    await yoks.connect()
    global.timestamp.connect = new Date
  }
})
    fs.existsSync('./session.json') && yoks.loadAuthInfo('./session.json')
    yoks.on('connecting', () => {
        start('2', 'Waiting New Message...')
    })
    yoks.on('open', () => {
    	console.log(chalk.greenBright('╭───────「  PHONE STAT」──────'))
        console.log(chalk.greenBright("├"))
        console.log(chalk.greenBright("├"), chalk.keyword("aqua")("[  STATS  ]"), chalk.whiteBright("WA Version : " + yoks.user.phone.wa_version))
        console.log(chalk.greenBright("├"), chalk.keyword("aqua")("[  STATS  ]"), chalk.whiteBright("OS Version : " + yoks.user.phone.os_version))
        console.log(chalk.greenBright("├"), chalk.keyword("aqua")("[  STATS  ]"), chalk.whiteBright("Device : " + yoks.user.phone.device_manufacturer))
        console.log(chalk.greenBright("├"), chalk.keyword("aqua")("[  STATS  ]"), chalk.whiteBright("Model : " + yoks.user.phone.device_model))
        console.log(chalk.greenBright("├"), chalk.keyword("aqua")("[  STATS  ]"), chalk.whiteBright("OS Build Number : " + yoks.user.phone.os_build_number))
        console.log(chalk.greenBright("├"), chalk.keyword("aqua")("[  STATS  ]"), chalk.whiteBright("You Number Phone : " + yoks.user.jid))
        console.log(chalk.greenBright("├"), chalk.keyword("aqua")("[  STATS  ]"), chalk.whiteBright('Connected'))
        console.log(chalk.greenBright("├"))
        console.log(chalk.greenBright('╰───────「  PHONE STAT」──────'))
    })
    await yoks.connect({timeoutMs: 30*1000})
        fs.writeFileSync('./session.json', JSON.stringify(yoks.base64EncodedAuthInfo(), null, '\t'))

    yoks.on('chat-update', async (message) => {
        require('./index.js')(yoks, message)
    })
}

async function _quickTest() {
  let test = await Promise.all([
    cp.spawn('ffmpeg'),
    cp.spawn('ffprobe'),
    cp.spawn('ffmpeg', ['-hide_banner', '-loglevel', 'error', '-filter_complex', 'color', '-frames:v', '1', '-f', 'webp', '-']),
    cp.spawn('convert'),
    cp.spawn('magick'),
    cp.spawn('gm'),
  ].map(p => {
    return Promise.race([
      new Promise(resolve => {
        p.on('close', code => {
          resolve(code !== 127)
        })
      }),
      new Promise(resolve => {
        p.on('error', _ => resolve(false))
      })
    ])
  }))
  let [ffmpeg, ffprobe, ffmpegWebp, convert, magick, gm] = test
  console.log(test)
  let s = global.support = {
    ffmpeg,
    ffprobe,
    ffmpegWebp,
    convert,
    magick,
    gm
  }
  require('./lib/sticker').support = s
  Object.freeze(global.support)
  }

/**
 * Uncache if there is file change
 * @param {string} module Module name or path
 * @param {function} cb <optional> 
 */
function nocache(module, cb = () => { }) {
    console.log('Module', `'${module}'`, 'is now being watched for changes')
    fs.watchFile(require.resolve(module), async () => {
        await uncache(require.resolve(module))
        cb(module)
    })
}

/**
 * Uncache a module
 * @param {string} module Module name or path
 */
function uncache(module = '.') {
    return new Promise((resolve, reject) => {
        try {
            delete require.cache[require.resolve(module)]
            resolve()
        } catch (e) {
            reject(e)
        }
    })
}

starts()
_quickTest()
