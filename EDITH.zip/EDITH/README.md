# SELF-WA
Install di termux

```bash
$ pkg update && pkg upgrade
$ pkg install git -y && pkg install ffmpeg -y && pkg install nodejs -y
$ git clone https://github.com/alanwildan/self
$ cd self
$ npm install
$ npm start

Tinggal Scan Qr Di WhatsApp Mu
```

## Thanks.

* [`ADIWAJSHING`](https://github.com/adiwajshing/Baileys) 
* [`Hafizh`](https://github.com/HAFizh-15) 
* [`MHANKBARBAR`](https://github.com/MhankBarBar)
* [`HEXAGONZ`](https://github.com/Hexagonz)
